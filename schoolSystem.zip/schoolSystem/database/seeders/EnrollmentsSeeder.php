<?php

namespace Database\Seeders;
use App\Models\Enrollments;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

use Illuminate\Database\Seeder;

class EnrollmentsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $json_file = File::get('database/data/enrollment-data.json'); 
        DB::table('enrollments')->delete(); 
        $data = json_decode($json_file); 
        foreach ($data as $obj) {
            Enrollments::create(array(
                'student_id' => $obj->student_id,
                'module_id' => $obj->module_id,
                'lecturer_id' => $obj->lecturer_id,
                'block' => $obj->block,
                'mark' => $obj->mark
            ));
        } 
    }
}
