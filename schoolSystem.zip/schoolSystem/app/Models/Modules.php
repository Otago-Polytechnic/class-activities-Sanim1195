<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Modules extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'credit', 'level'];
    public function enrollments() {
        return $this->hasMany(Enrollments::class); // This is an example of a relationship - an institution can have many students
        }
}
