<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Enrollments;

class EnrollmentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Enrollments::join('students', 'enrollments.student_id', '=', 'students.id')
        ->join('modules', 'enrollments.module_id', '=', 'modules.id')
        ->get([
            'enrollments.block', 
            'enrollments.mark', 
            'students.first_name',
            'students.phone_number',
            'modules.name',
            'modules.credit'
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'student_id' => 'required',
            'module_id' => 'required',
            'lecturer_id' => 'required',
            'block' => 'required',
            'mark' => 'required'
        ]);
        return Enrollments::create($request->all());
    
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Enrollments::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $enrollments = Enrollments::find($id);
        $enrollments->update($request->all());
        return $enrollments;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Enrollments::destroy($id);
    }
}
