<?php
use App\Http\Controllers\StudentsController;
use App\Http\Controllers\InstitutionController;
use App\Http\Controllers\ModulesController;
use App\Http\Controllers\LecturersController;
use App\Http\Controllers\EnrollmentsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

    Route::group(['prefix' => 'institutions'], function () {
    Route::get('/', [InstitutionController::class, 'index']);
    Route::get('/{id}', [InstitutionController::class, 'show']);
    Route::post('/', [InstitutionController::class, 'store']);
    Route::put('/{id}', [InstitutionController::class, 'update']);
    Route::delete('/{id}', [InstitutionController::class, 'destroy']);
    });

    Route::group(['prefix' => 'students'], function () {
    Route::get('/', [StudentsController::class, 'index']);
    Route::get('/{id}', [StudentsController::class, 'show']);
    Route::post('/', [StudentsController::class, 'store']);
    Route::put('/{id}', [StudentsController::class, 'update']);
    Route::delete('/{id}', [StudentsController::class, 'destroy']);
    });

    Route::group(['prefix' => 'modules'], function () {
    Route::get('/', [ModulesController::class, 'index']);
    Route::get('/{id}', [ModulesController::class, 'show']);
    Route::post('/', [ModulesController::class, 'store']);
    Route::put('/{id}', [ModulesController::class, 'update']);
    Route::delete('/{id}', [ModulesController::class, 'destroy']);
    });

    Route::group(['prefix' => 'lecturers'], function () {
    Route::get('/', [LecturersController::class, 'index']);
    Route::get('/{id}', [LecturersController::class, 'show']);
    Route::post('/', [LecturersController::class, 'store']);
    Route::put('/{id}', [LecturersController::class, 'update']);
    Route::delete('/{id}', [LecturersController::class, 'destroy']);
    });

    Route::group(['prefix' => 'enrollments'], function () {
        Route::get('/', [EnrollmentsController::class, 'index']);
        Route::get('/{id}', [EnrollmentsController::class, 'show']);
        Route::post('/', [EnrollmentsController::class, 'store']);
        Route::put('/{id}', [EnrollmentsController::class, 'update']);
        Route::delete('/{id}', [EnrollmentsController::class, 'destroy']);
        });
    
